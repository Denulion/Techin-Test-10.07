let names = ["Olivia", "Jackson", "Sophia", "Elijah", "Ava", "Liam", "Isabella"];

const deleteOlivia = (arr) => {
    const index = arr.indexOf("Olivia");
    arr.splice(index, 1);
    return arr;
}
const addMason = (arr) => {
    arr.unshift("Mason");
    return arr;
}
const addMyName = (arr) => {
    arr.push("Andrej");
    return arr;
}
const removeCustomName = (name, arr) => {
    const index = arr.indexOf(name);
    arr.splice(index, 1);
    return arr;
}
console.log(deleteOlivia(names));
console.log(addMason(names));
console.log(addMyName(names));
console.log(removeCustomName("Sophia", names));
const withBob = names.map((x) => x + "withBob");
console.log(withBob);

names.sort();
names.reverse();

console.log(names);

