function sumEven(num) {
    let even = 0;
    for (let i = 0; i < num; i++) {
        if (i % 2 === 0) {
            even += i;
        }
    }
    return even;
}

function sumOdd(num) {
    let odd = 0;
    for (let i = 0; i < num; i++) {
        if (i % 2 !== 0) {
            odd += i;
        }
    }
    return odd;
}

console.log(sumEven(100));
console.log(sumOdd(100));