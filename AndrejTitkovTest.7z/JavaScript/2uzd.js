const exercises = ["Push-ups", "Sit-ups", "Bear Crawls", "1 mile run", "60 second plank", "Burpees", "Jumping Jacks", "Squats", "Weighted Squats", "Inch Worms"];

const getExercises = (num) => {
    if (num > exercises.length) {
        return "You entered more exercises than exists";
    } else if (num <= 0) {
        return "You entered less exercises than exists";
    } else {
        const chosenExercises = [];
        for (let i = 0; i < num; i++) {
            const randomExercise = Math.floor(Math.random() * exercises.length);
            chosenExercises.push(exercises[randomExercise]);
        }
        return chosenExercises;
    }
}

console.log(getExercises(4));
