const coinLoop = () => {
    let coinBank = 0;
    let bool = true;
    while (bool == true) {
        let userInput = prompt(`You have ${coinBank} coins. Do you want a coin? Yes/No`);
        if (userInput === "Yes") {
            coinBank++;
            bool = true;
        }else if (userInput === "No") {
            bool = false;
        }
    }
    alert(`You have: ${coinBank} coins! Bye!`);
}

coinLoop();