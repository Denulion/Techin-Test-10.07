const inputPercent = document.getElementById("percent");
const inputNumber = document.getElementById("number");
const output = document.getElementById("output");
const calcButton = document.getElementById("calcButton");

function calculate() {
    let percent = inputPercent.value;
    let num = inputNumber.value;

    output.innerHTML = (percent/100) * num;
}

calcButton.addEventListener("click", calculate);